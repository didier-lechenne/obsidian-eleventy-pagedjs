/**
 * @file Manage text alignement
 * A interface to manually but easily handle non-breaking spaces and letterspacing of textuals elements, in the browser.
 * @author Benjamin G. <ecrire@bnjm.eu>
 * @see https://gitlab.com/BenjmnG/beauDrapeau
 */

// État global partagé - CORRECTION PRINCIPALE
const state = {
  isEditMode: false,
  currentEditingElement: null
};

export const beauDrapeau = () => ({

  // Référence à l'état global au lieu de propriétés locales
  get isEditMode() { return state.isEditMode; },
  set isEditMode(value) { state.isEditMode = value; },
  
  get currentEditingElement() { return state.currentEditingElement; },
  set currentEditingElement(value) { state.currentEditingElement = value; },

  // Nouvelles méthodes helper pour le formatage moderne
  formatting: {
    /**
     * Toggle bold formatting using modern Selection API
     * @param {Selection} selection - Window selection object
     */
    toggleBold(selection) {
      if (!selection.rangeCount || selection.isCollapsed) return;
      
      const range = selection.getRangeAt(0);
      const selectedContent = range.extractContents();
      
      // Vérifier si la sélection contient déjà du formatage bold AJOUTÉ par beauDrapeau
      const hasBeauDrapeauBold = this.containsBeauDrapeauElements(selectedContent, 'strong') ||
                                this.containsBeauDrapeauElements(selectedContent, 'b');
      
      if (hasBeauDrapeauBold) {
        // Retirer SEULEMENT le formatage bold ajouté par beauDrapeau
        this.removeBeauDrapeauFormatting(selectedContent, ['strong', 'b']);
        range.insertNode(selectedContent);
      } else {
        // Ajouter le formatage gras avec classe de traçage
        const strong = document.createElement('strong');
        strong.classList.add('beau-drapeau-added'); // ← CLASSE DE TRAÇAGE
        strong.appendChild(selectedContent);
        range.insertNode(strong);
      }
      
      // Restaurer la sélection
      this.restoreSelection(selection, range);
    },

    /**
     * Toggle italic formatting using modern Selection API
     * @param {Selection} selection - Window selection object
     */
    toggleItalic(selection) {
      if (!selection.rangeCount || selection.isCollapsed) return;
      
      const range = selection.getRangeAt(0);
      const selectedContent = range.extractContents();
      
      // Vérifier si la sélection contient déjà du formatage italic AJOUTÉ par beauDrapeau
      const hasBeauDrapeauItalic = this.containsBeauDrapeauElements(selectedContent, 'em') ||
                                  this.containsBeauDrapeauElements(selectedContent, 'i');
      
      if (hasBeauDrapeauItalic) {
        // Retirer SEULEMENT le formatage italic ajouté par beauDrapeau
        this.removeBeauDrapeauFormatting(selectedContent, ['em', 'i']);
        range.insertNode(selectedContent);
      } else {
        // Ajouter le formatage italique avec classe de traçage
        const em = document.createElement('em');
        em.classList.add('beau-drapeau-added'); // ← CLASSE DE TRAÇAGE
        em.appendChild(selectedContent);
        range.insertNode(em);
      }
      
      // Restaurer la sélection
      this.restoreSelection(selection, range);
    },

    /**
     * Check if element or its parents have bold formatting
     */
    isElementBold(element) {
      if (!element || element === document.body) return false;
      
      const tagName = element.tagName?.toLowerCase();
      if (tagName === 'strong' || tagName === 'b') return true;
      
      const fontWeight = window.getComputedStyle(element).fontWeight;
      if (parseInt(fontWeight) >= 700 || fontWeight === 'bold') return true;
      
      return this.isElementBold(element.parentElement);
    },

    /**
     * Check if element or its parents have italic formatting
     */
    isElementItalic(element) {
      if (!element || element === document.body) return false;
      
      const tagName = element.tagName?.toLowerCase();
      if (tagName === 'em' || tagName === 'i') return true;
      
      const fontStyle = window.getComputedStyle(element).fontStyle;
      if (fontStyle === 'italic') return true;
      
      return this.isElementItalic(element.parentElement);
    },

    /**
     * Check if document fragment contains beauDrapeau-added elements of specific tags
     */
    containsBeauDrapeauElements(fragment, tagName) {
      const elements = fragment.querySelectorAll(`${tagName}.beau-drapeau-added`);
      return elements.length > 0;
    },

    /**
     * Remove only beauDrapeau-added formatting from document fragment
     */
    removeBeauDrapeauFormatting(fragment, tagNames) {
      tagNames.forEach(tagName => {
        const elements = fragment.querySelectorAll(`${tagName}.beau-drapeau-added`);
        elements.forEach(element => {
          // Remplacer l'élément par son contenu
          while (element.firstChild) {
            element.parentNode.insertBefore(element.firstChild, element);
          }
          element.remove();
        });
      });
    },

    /**
     * Restore selection after formatting change
     */
    restoreSelection(selection, range) {
      // Créer une nouvelle range pour la sélection restaurée
      const newRange = document.createRange();
      newRange.selectNodeContents(range.commonAncestorContainer);
      
      selection.removeAllRanges();
      selection.addRange(newRange);
    }
  },

  ui: () => ({

    toggle: () => ({

      button: (id) => {
        var button = document.getElementById(id);

        if(!button){
          return
        }
        // Toggle button value
        if (state.isEditMode) {
            button.classList.add('active')
            button.value = 'Edit On';
        } else {
            button.classList.remove('active')
            button.value = 'Edit Off';
        }
      },

      /**
       * Active/désactive la possibilité de cliquer sur les éléments pour les éditer
       */
      contentEditable: () => {
        const editableElements = document.querySelectorAll('[editable-id]');
        
        if (state.isEditMode) {
          // Mode édition ON : ajouter les event listeners pour la sélection
          editableElements.forEach((element) => {
            element.style.cursor = 'pointer';
            element.style.outline = '1px dashed #ccc';
            
            // Créer une fonction pour chaque élément
            const clickHandler = (event) => {
              event.preventDefault();
              event.stopPropagation();
              
              const clickedElement = event.target;
              const editableId = clickedElement.getAttribute('editable-id');
              
              if (!editableId) return;
              
              // Désélectionner l'élément précédent s'il y en avait un
              if (state.currentEditingElement) {
                state.currentEditingElement.contentEditable = false;
                state.currentEditingElement.style.backgroundColor = '';
                state.currentEditingElement.style.outline = '1px dashed #ccc';
              }
              
              // Sélectionner le nouvel élément
              state.currentEditingElement = clickedElement;
              clickedElement.contentEditable = true;
              clickedElement.style.backgroundColor = '#e3f2fd';
              clickedElement.style.outline = '2px solid #2196F3';
              clickedElement.focus();
              
              console.log(`Élément ${editableId} sélectionné pour édition`);
            };
            
            element.addEventListener('click', clickHandler);
            // Stocker la référence pour pouvoir la supprimer plus tard
            element._beauDrapeauClickHandler = clickHandler;
          });
        } else {
          // Mode édition OFF : nettoyer
          editableElements.forEach((element) => {
            element.style.cursor = '';
            element.style.outline = '';
            element.style.backgroundColor = '';
            element.contentEditable = false;
            
            // Supprimer l'event listener stocké
            if (element._beauDrapeauClickHandler) {
              element.removeEventListener('click', element._beauDrapeauClickHandler);
              delete element._beauDrapeauClickHandler;
            }
          });
          
          // Copier le contenu si un élément était en cours d'édition
          if (state.currentEditingElement) {
            beauDrapeau().ui().copyToClipboard();
            state.currentEditingElement = null;
          }
        }
      },
    }),

    // Fonction pour copier le contenu du bloc édité dans le presse-papier
    copyToClipboard: async () => {
      if (!state.currentEditingElement) {
        console.log('Aucun élément en cours d\'édition');
        return;
      }
      
      const htmlContent = state.currentEditingElement.innerHTML;
      const blockId = state.currentEditingElement.getAttribute('editable-id');
      
      if (!htmlContent) {
        console.log('Aucun contenu à copier');
        return;
      }
      
      let contentToCopy = htmlContent;
      let format = 'HTML';
      
      // Essayer de convertir en Markdown si Turndown est disponible
      if (typeof TurndownService !== 'undefined') {
        try {
          const turndownService = new TurndownService({
            headingStyle: 'atx',
            hr: '---',
            bulletListMarker: '-',
            codeBlockStyle: 'fenced',
            fence: '```',
            emDelimiter: '*',
            strongDelimiter: '**',
            linkStyle: 'inlined',
            linkReferenceStyle: 'full'
          });
          
          // Règles personnalisées pour les espaces insécables
          turndownService.addRule('nonBreakingSpaces', {
            filter: function (node) {
              return node.nodeType === 3 && /\u00A0/.test(node.textContent);
            },
            replacement: function (content) {
              return content.replace(/\u00A0/g, '&nbsp;');
            }
          });

          // Règle personnalisée pour préserver les spans avec --ls
          turndownService.addRule('letterSpacingSpans', {
            filter: function (node) {
              return node.nodeName === 'SPAN' && node.classList.contains('letterSpacing');
            },
            replacement: function (content, node) {
              const lsValue = node.style.getPropertyValue('--ls');
              return `<span style="--ls:${lsValue}">${content}</span>`;
            }
          });
          
          contentToCopy = turndownService.turndown(htmlContent);
          format = 'Markdown';
          console.log(`Contenu du bloc ${blockId} converti en Markdown:`, contentToCopy);
        } catch (err) {
          console.warn('Erreur lors de la conversion Markdown, copie du HTML:', err);
          contentToCopy = htmlContent;
          format = 'HTML (fallback)';
        }
      } else {
        console.warn('TurndownService non disponible, copie du HTML brut');
      }
      
      try {
        await navigator.clipboard.writeText(contentToCopy);
        console.log(`Contenu du bloc ${blockId} copié en ${format}:`, contentToCopy);
        
        // Notification visuelle avec l'ID du bloc et le format
        const notification = document.createElement('div');
        notification.textContent = `✓ Bloc ${blockId} copié en ${format}`;
        notification.style.cssText = `
          position: fixed;
          top: 1rem;
          right: 1rem;
          background: #4CAF50;
          color: white;
          padding: 0.5rem 1rem;
          border-radius: 4px;
          z-index: 1000;
          font-family: sans-serif;
          font-size: 14px;
        `;
        document.body.appendChild(notification);
        
        setTimeout(() => {
          if (document.body.contains(notification)) {
            document.body.removeChild(notification);
          }
        }, 3000);
        
      } catch (err) {
        console.error('Erreur lors de la copie:', err);
        // Fallback pour les navigateurs plus anciens
        const textArea = document.createElement('textarea');
        textArea.value = contentToCopy;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
        
        // Notification pour le fallback
        const notification = document.createElement('div');
        notification.textContent = `✓ Bloc ${blockId} copié en ${format} (fallback)`;
        notification.style.cssText = `
          position: fixed;
          top: 1rem;
          right: 1rem;
          background: #FF9800;
          color: white;
          padding: 0.5rem 1rem;
          border-radius: 4px;
          z-index: 1000;
          font-family: sans-serif;
          font-size: 14px;
        `;
        document.body.appendChild(notification);
        
        setTimeout(() => {
          if (document.body.contains(notification)) {
            document.body.removeChild(notification);
          }
        }, 3000);
      }
    },

    event: () => ({
      letterSpacing: () => {
        let letterSpacing = 0;

        const applyLetterSpacingToElement = (element, newLetterSpacing) => {
          // Vérifier s'il y a déjà un span avec --ls qui entoure tout le contenu
          let existingSpan = null;
          if (element.children.length === 1 && 
              element.children[0].tagName === 'SPAN' && 
              element.children[0].classList.contains('letterSpacing') &&
              element.children[0].classList.contains('beau-drapeau-added')) {
            existingSpan = element.children[0];
          }

          if (existingSpan) {
            // Modifier la valeur existante
            existingSpan.style.setProperty('--ls', newLetterSpacing.toFixed(2));
          } else {
            // Créer un nouveau span qui entoure tout le contenu
            const span = document.createElement('span');
            span.classList.add('letterSpacing');
            span.classList.add('beau-drapeau-added'); // ← CLASSE DE TRAÇAGE
            span.style.setProperty('--ls', newLetterSpacing.toFixed(2));
            
            // Déplacer tout le contenu existant dans le span
            while (element.firstChild) {
              span.appendChild(element.firstChild);
            }
            
            // Ajouter le span à l'élément
            element.appendChild(span);
          }
        };

        const handleScroll = (event) => {
          // Vérifier si on est sur l'élément sélectionné OU sur son span letter-spacing
          const isTargetElement = event.target === state.currentEditingElement;
          const isTargetSpan = event.target.classList && 
                              event.target.classList.contains('letterSpacing') && 
                              event.target.classList.contains('beau-drapeau-added') &&
                              event.target.parentElement === state.currentEditingElement;
          
          if (event.shiftKey && (isTargetElement || isTargetSpan)) {
            event.preventDefault();
            
            const step = 0.01;
            const newLetterSpacing = event.deltaY > 0 ? letterSpacing - step : letterSpacing + step;
            
            // Obtenir la valeur actuelle s'il y a déjà un span
            const currentElement = state.currentEditingElement;
            const existingSpan = currentElement.querySelector('span.letterSpacing.beau-drapeau-added');
            if (existingSpan) {
              const currentValue = parseFloat(existingSpan.style.getPropertyValue('--ls')) || 0;
              letterSpacing = event.deltaY > 0 ? currentValue - step : currentValue + step;
            } else {
              letterSpacing = newLetterSpacing;
            }
            
            applyLetterSpacingToElement(currentElement, letterSpacing);
            
            console.log(`Letter spacing appliqué sur tout l'élément: --ls:${letterSpacing.toFixed(2)}`);
          }
        };

        const handleMouseOver = (event) => {
          const isTargetElement = event.target === state.currentEditingElement;
          const isTargetSpan = event.target.classList && 
                              event.target.classList.contains('letterSpacing') && 
                              event.target.classList.contains('beau-drapeau-added') &&
                              event.target.parentElement === state.currentEditingElement;
          
          if (isTargetElement || isTargetSpan) {
            const targetElement = isTargetElement ? event.target : event.target.parentElement;
            targetElement.addEventListener('wheel', handleScroll);
            targetElement.addEventListener('mouseleave', handleMouseOut);
          }
        };

        const handleMouseOut = (event) => {
          const isTargetElement = event.target === state.currentEditingElement;
          const isTargetSpan = event.target.classList && 
                              event.target.classList.contains('letterSpacing') && 
                              event.target.classList.contains('beau-drapeau-added') &&
                              event.target.parentElement === state.currentEditingElement;
          
          if (isTargetElement || isTargetSpan) {
            const targetElement = isTargetElement ? event.target : event.target.parentElement;
            targetElement.removeEventListener('wheel', handleScroll);
            targetElement.removeEventListener('mouseleave', handleMouseOut);
          }
        };

        if (state.isEditMode) {
          document.addEventListener('mouseover', handleMouseOver);
          document.addEventListener('mouseout', handleMouseOut);
        } else {
          document.removeEventListener('mouseover', handleMouseOver);
          document.removeEventListener('mouseout', handleMouseOut);
        }
      },

      reset: () => {
        const handleKeyDown = (event) => {
          const isTargetElement = event.target === state.currentEditingElement;
          const isTargetSpan = event.target.classList && 
                              event.target.classList.contains('letterSpacing') && 
                              event.target.classList.contains('beau-drapeau-added') &&
                              event.target.parentElement === state.currentEditingElement;
          
          if (event.shiftKey && event.key === 'R' && (isTargetElement || isTargetSpan)) {
            event.preventDefault();
            const targetElement = isTargetElement ? event.target : event.target.parentElement;
            const id = targetElement.getAttribute('editable-id');
            beauDrapeau().clear(id);
          }
        };
        
        if (state.isEditMode) {
          document.addEventListener('keydown', handleKeyDown);
        } else {
          document.removeEventListener('keydown', handleKeyDown);
        }
      },

      // Événements pour ajouter des espaces insécables et des sauts de ligne
      nonBreakingSpace: () => {
        const handleKeyDown = (event) => {
          const isTargetElement = event.target === state.currentEditingElement;
          const isTargetSpan = event.target.classList && 
                              event.target.classList.contains('letterSpacing') && 
                              event.target.classList.contains('beau-drapeau-added') &&
                              event.target.parentElement === state.currentEditingElement;
          
          // Shift + Enter = Saut de ligne <br class="beau-drapeau-added">
          if (event.shiftKey && event.key === 'Enter' && (isTargetElement || isTargetSpan)) {
            event.preventDefault();
            
            // Ajouter un saut de ligne avec classe de traçage
            const selection = window.getSelection();
            const range = selection.getRangeAt(0);
            
            const br = document.createElement('br');
            br.classList.add('beau-drapeau-added');
            range.insertNode(br);
            
            // Repositionner le curseur après le <br>
            range.setStartAfter(br);
            range.setEndAfter(br);
            selection.removeAllRanges();
            selection.addRange(range);
            
            console.log('Saut de ligne beauDrapeau ajouté');
          }
          
          // Shift + Space (sans Ctrl) = Espace insécable normal (\u00A0)
          else if (event.shiftKey && !event.ctrlKey && event.code === 'Space' && (isTargetElement || isTargetSpan)) {
            event.preventDefault();
            
            // Ajouter un espace insécable normal à la position du curseur
            const selection = window.getSelection();
            const range = selection.getRangeAt(0);
            
            const nbsp = document.createTextNode('\u00A0');
            range.insertNode(nbsp);
            
            // Repositionner le curseur après l'espace insécable
            range.setStartAfter(nbsp);
            range.setEndAfter(nbsp);
            selection.removeAllRanges();
            selection.addRange(range);
            
            console.log('Espace insécable normal ajouté');
          }
          
          // Shift + Ctrl + Space = Espace insécable fine (\u202F)
          else if (event.shiftKey && event.ctrlKey && event.code === 'Space' && (isTargetElement || isTargetSpan)) {
            event.preventDefault();
            
            // Ajouter un espace insécable fine à la position du curseur
            const selection = window.getSelection();
            const range = selection.getRangeAt(0);
            
            const thinNbsp = document.createTextNode('\u202F');
            range.insertNode(thinNbsp);
            
            // Repositionner le curseur après l'espace insécable fine
            range.setStartAfter(thinNbsp);
            range.setEndAfter(thinNbsp);
            selection.removeAllRanges();
            selection.addRange(range);
            
            console.log('Espace insécable fine ajouté');
          }
        };

        if (state.isEditMode) {
          document.addEventListener('keydown', handleKeyDown);
        } else {
          document.removeEventListener('keydown', handleKeyDown);
        }
      },

      // RACCOURCIS CLAVIER POUR LE FORMATAGE - VERSION MODERNISÉE
      textFormatting: () => {
        const handleKeyDown = (event) => {
          const isTargetElement = event.target === state.currentEditingElement;
          const isTargetSpan = event.target.classList && 
                              event.target.classList.contains('letterSpacing') && 
                              event.target.classList.contains('beau-drapeau-added') &&
                              event.target.parentElement === state.currentEditingElement;
          
          if (!isTargetElement && !isTargetSpan) {
            return;
          }

          const selection = window.getSelection();
          
          // Shift + B pour toggle bold (VERSION MODERNE)
          if (event.shiftKey && event.key === 'B') {
            event.preventDefault();
            
            if (selection.rangeCount > 0 && !selection.isCollapsed) {
              // Utiliser la nouvelle méthode moderne
              beauDrapeau().formatting.toggleBold(selection);
              console.log('Toggle bold moderne appliqué à la sélection');
            } else {
              console.log('Aucune sélection pour appliquer le gras');
            }
          }
          
          // Shift + I pour toggle italique (VERSION MODERNE)
          else if (event.shiftKey && event.key === 'I') {
            event.preventDefault();
            
            if (selection.rangeCount > 0 && !selection.isCollapsed) {
              // Utiliser la nouvelle méthode moderne
              beauDrapeau().formatting.toggleItalic(selection);
              console.log('Toggle italique moderne appliqué à la sélection');
            } else {
              console.log('Aucune sélection pour appliquer l\'italique');
            }
          }
        };

        const handleInput = (event) => {
          const isTargetElement = event.target === state.currentEditingElement;
          const isTargetSpan = event.target.classList && 
                              event.target.classList.contains('letterSpacing') && 
                              event.target.classList.contains('beau-drapeau-added') &&
                              event.target.parentElement === state.currentEditingElement;
          
          if (!isTargetElement && !isTargetSpan) {
            return;
          }

          // Détecter >> et remplacer par [espace fine insécable]»[espace normal]
          if (event.inputType === 'insertText' && event.data === '>') {
            const selection = window.getSelection();
            const range = selection.getRangeAt(0);
            const textNode = range.startContainer;
            
            if (textNode.nodeType === Node.TEXT_NODE) {
              const textContent = textNode.textContent;
              const cursorPos = range.startOffset;
              
              // Vérifier s'il y a un > juste avant la position actuelle
              if (cursorPos >= 2 && textContent.substring(cursorPos - 2, cursorPos) === '>>') {
                // Toujours insérer espace fine insécable avant » et espace normal après
                let replacement = '\u202F»';
                
            
                // Remplacer >> par [espace fine insécable]»[espace normal si nécessaire]
                const newText = textContent.substring(0, cursorPos - 2) + replacement + textContent.substring(cursorPos);
                textNode.textContent = newText;
                
                // Repositionner le curseur
                const newCursorPos = cursorPos - 2 + replacement.length;
                range.setStart(textNode, newCursorPos);
                range.setEnd(textNode, newCursorPos);
                selection.removeAllRanges();
                selection.addRange(range);
                
                console.log('>> remplacé par [espace fine insécable]»[espace normal]');
              }
            }
          }
          
          // Détecter << et remplacer par [espace normal]«[espace fine insécable]
          else if (event.inputType === 'insertText' && event.data === '<') {
            const selection = window.getSelection();
            const range = selection.getRangeAt(0);
            const textNode = range.startContainer;
            
            if (textNode.nodeType === Node.TEXT_NODE) {
              const textContent = textNode.textContent;
              const cursorPos = range.startOffset;
              
              // Vérifier s'il y a un < juste avant la position actuelle
              if (cursorPos >= 2 && textContent.substring(cursorPos - 2, cursorPos) === '<<') {
                // Toujours insérer espace normal avant « et espace fine insécable après
                let replacement = '«\u202F';
                

                
                // Remplacer << par [espace normal si nécessaire]«[espace fine insécable]
                const newText = textContent.substring(0, cursorPos - 2) + replacement + textContent.substring(cursorPos);
                textNode.textContent = newText;
                
                // Repositionner le curseur
                const newCursorPos = cursorPos - 2 + replacement.length;
                range.setStart(textNode, newCursorPos);
                range.setEnd(textNode, newCursorPos);
                selection.removeAllRanges();
                selection.addRange(range);
                
                console.log('<< remplacé par [espace normal]«[espace fine insécable]');
              }
            }
          }
        };

        if (state.isEditMode) {
          document.addEventListener('keydown', handleKeyDown);
          document.addEventListener('input', handleInput);
        } else {
          document.removeEventListener('keydown', handleKeyDown);
          document.removeEventListener('input', handleInput);
        }
      }
    }),



  }),

  /**
   * Toggle du mode édition (appelé par le script principal)
   */
  edit: () => {
    state.isEditMode = !state.isEditMode;

    // update UI
    beauDrapeau().ui().toggle().button('edit-button')

    // Toggle the ContentEditable system
    beauDrapeau().ui().toggle().contentEditable()

    // Initialize event listeners
    beauDrapeau().ui().event().letterSpacing();
    beauDrapeau().ui().event().reset();
    beauDrapeau().ui().event().nonBreakingSpace();
    beauDrapeau().ui().event().textFormatting(); // Maintenant avec méthodes modernes
  },

  clear: (ids) => {
    // Convert the `ids` argument to an array if it's not already an array
    if (!Array.isArray(ids)) {
      ids = [ids];
    }

    // Loop through each ID in the `ids` array
    ids.forEach((id) => {
      // Get the corresponding DOM element by ID
      console.log("Clear element ", id)
      const element = document.querySelector("[editable-id='"+id+"']");

      if (element) {
        // 1. Remove inline letter-spacing styles
        element.style.letterSpacing = '';
        
        // 2. Remove ONLY beauDrapeau-added letter-spacing spans (preserve original spans)
        const beauDrapeauLetterSpacingSpans = element.querySelectorAll('span.letterSpacing.beau-drapeau-added');
        beauDrapeauLetterSpacingSpans.forEach(span => {
          span.replaceWith(...span.childNodes);
        });

        // 3. Remove ONLY beauDrapeau-added bold/italic formatting (preserve original formatting)
        const beauDrapeauBoldElements = element.querySelectorAll('strong.beau-drapeau-added, b.beau-drapeau-added');
        beauDrapeauBoldElements.forEach(boldElement => {
          boldElement.replaceWith(...boldElement.childNodes);
        });

        const beauDrapeauItalicElements = element.querySelectorAll('em.beau-drapeau-added, i.beau-drapeau-added');
        beauDrapeauItalicElements.forEach(italicElement => {
          italicElement.replaceWith(...italicElement.childNodes);
        });

        // 4. Remove ONLY beauDrapeau-added line breaks (preserve original <br>)
        const beauDrapeauLineBreaks = element.querySelectorAll('br.beau-drapeau-added');
        beauDrapeauLineBreaks.forEach(br => {
          br.remove();
        });
        
        // Note: Les espaces insécables (normaux et fins) ne sont JAMAIS supprimés 
        // car ils peuvent être légitimes dans le contenu original ET sont utiles 
        // pour la typographie même s'ils ont été ajoutés manuellement
        
        console.log(`Élément ${id} nettoyé (formatage beauDrapeau seulement, espaces insécables préservés)`);
      }
    });
  },
})