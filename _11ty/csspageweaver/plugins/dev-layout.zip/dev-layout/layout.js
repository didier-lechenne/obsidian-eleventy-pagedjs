// layout.js - Point d'entrée principal du plugin layout avec injection de dépendances

import { gridHandler } from './gridHandler.js';
import { imageHandler } from './imageHandler.js';
import { codeGenerator } from './codeGenerator.js';
import { Handler } from "/csspageweaver/lib/paged.esm.js";

/**
 * Gestionnaire principal du plugin Layout pour PagedJS
 * Orchestre la grille modulaire, la manipulation d'images et la génération de code
 */
export default class Layout extends Handler {
    constructor(chunker, polisher, caller) {
        super(chunker, polisher, caller);
        
        // ✅ Ordre d'initialisation important : codeGenerator en premier
        this.codeGenerator = new codeGenerator();
        this.gridHandler = new gridHandler(); // ✅ On injectera la référence après
        this.imageHandler = new imageHandler();
        
        this.isInitialized = false;
        this.toggleHandler = null;
        this.fileTitle = cssPageWeaver.docTitle;
        
        console.log('🚀 Layout Plugin: Initialisation...');
    }

    beforeParsed(content) {
        this.cleanup();
    }

    afterRendered(pages) {
        // Délai pour s'assurer que le DOM est prêt
        setTimeout(() => {
            this.initializeHandlers();
            this.initializeLayoutToggle();
            this.isInitialized = true;
            console.log('✅ Layout Plugin: Prêt');
        }, 100);
    }

    initializeHandlers() {
        try {
            // ✅ ÉTAPE 1: Initialiser le codeGenerator en premier
            this.codeGenerator.initialize();
            console.log('✅ CodeGenerator initialisé');
            
            // ✅ ÉTAPE 2: Injecter la référence dans gridHandler
            // this.gridHandler.setCodeGenerator(this.codeGenerator);
            this.gridHandler.initialize();
            console.log('✅ GridHandler initialisé avec référence codeGenerator');
            
            // ✅ ÉTAPE 3: Initialiser imageHandler
            this.imageHandler.initialize();
            console.log('✅ ImageHandler initialisé');
            
            // ✅ ÉTAPE 4: Rendre les composants disponibles globalement pour debug
            if (typeof window !== 'undefined') {
                window.LayoutPlugin = {
                    Layout: this,
                    gridHandler: this.gridHandler,
                    imageHandler: this.imageHandler,
                    codeGenerator: this.codeGenerator
                };
                console.log('✅ LayoutPlugin exposé globalement pour debug');
            }
            
            console.log('🎯 Tous les handlers sont initialisés et connectés');
        } catch (error) {
            console.error('❌ Erreur initialisation handlers:', error);
        }
    }

    initializeLayoutToggle() {
        if (this.toggleHandler) return; // Éviter les doublons

        console.log('🎛️ Initialisation du toggle Layout...');
        
        // Vérifications avec fallbacks
        let body = cssPageWeaver?.ui?.body;
        let toggleInput = cssPageWeaver?.ui?.layout?.toggleInput;
        
        // Fallback pour body
        if (!body) {
            console.warn('⚠️ cssPageWeaver.ui.body non trouvé, utilisation de document.body');
            body = document.body;
        }
        
        // Fallback pour toggleInput - chercher dans le DOM
        if (!toggleInput) {
            console.warn('⚠️ cssPageWeaver.ui.layout.toggleInput non trouvé, recherche dans le DOM...');
            
            // Essayer plusieurs sélecteurs possibles
            const selectors = [
                'input[data-plugin="layout"]',
                '#layout-toggle',
                'input[name="layout"]',
                '.layout-toggle input',
                '[data-toggle="layout"]'
            ];
            
            for (const selector of selectors) {
                toggleInput = document.querySelector(selector);
                if (toggleInput) {
                    console.log(`✅ Toggle trouvé avec sélecteur: ${selector}`);
                    break;
                }
            }
            
            if (!toggleInput) {
                console.error('❌ Aucun toggle trouvé - le mode layout ne pourra pas être activé');
                return;
            }
        }

        console.log('✅ Body et toggle trouvés');

        // Récupérer la préférence sauvegardée
        const preference = localStorage.getItem('layout') === 'true';
        
        body.classList.toggle('layout', preference);
        toggleInput.checked = preference;
        
        console.log(`🔧 État initial: layout=${body.classList.contains('layout')}`);

        // Créer le handler d'événement
        this.toggleHandler = (e) => {
            const isEnabled = e.target.checked;
            body.classList.toggle("layout", isEnabled);
            localStorage.setItem('layout', isEnabled);
            
            if (isEnabled) {
                console.log('🟢 Mode Layout activé');
            } else {
                console.log('🔴 Mode Layout désactivé');
            }
            
            // Debug: vérifier que la classe est bien appliquée
            console.log('🔍 Classe layout présente:', body.classList.contains('layout'));
        };
        
        toggleInput.addEventListener("input", this.toggleHandler);
        console.log('🎛️ Toggle Layout configuré');
    }

    // ✅ NOUVELLE méthode pour tester la copie
    testClipboardIntegration() {
        console.log('🧪 Test de l\'intégration clipboard...');
        
        // Attendre que tout soit initialisé
        setTimeout(() => {
            const testElement = document.querySelector('.resize, .figure, .insert');
            if (testElement && this.codeGenerator) {
                console.log('🧪 Test de génération et copie...');
                const code = this.codeGenerator.generate(testElement, false);
                console.log('📝 Code généré:', code);
                
                if (code) {
                    this.codeGenerator.copyWithFeedback(code);
                    console.log('✅ Test de copie effectué');
                } else {
                    console.warn('⚠️ Aucun code généré pour le test');
                }
            } else {
                console.warn('⚠️ Pas d\'élément de test trouvé ou codeGenerator manquant');
            }
        }, 1000);
    }

    cleanup() {
        if (!this.isInitialized) return;

        try {
            // Nettoyer les handlers
            if (this.gridHandler) {
                this.gridHandler.cleanup();
            }
            
            if (this.imageHandler) {
                this.imageHandler.cleanup();
            }
            
            if (this.codeGenerator) {
                this.codeGenerator.cleanup();
            }

            // Nettoyer le toggle
            if (this.toggleHandler && cssPageWeaver.ui.layout.toggleInput) {
                cssPageWeaver.ui.layout.toggleInput.removeEventListener("input", this.toggleHandler);
                this.toggleHandler = null;
            }

            // Nettoyer la référence globale
            if (typeof window !== 'undefined' && window.LayoutPlugin) {
                delete window.LayoutPlugin;
            }

            this.isInitialized = false;
            console.log('🧹 Layout Plugin nettoyé');
            
        } catch (error) {
            console.error('❌ Erreur lors du nettoyage:', error);
        }
    }

    destroy() {
        this.cleanup();
        
        if (this.gridHandler) this.gridHandler.destroy();
        if (this.imageHandler) this.imageHandler.destroy();
        if (this.codeGenerator) this.codeGenerator.destroy();
        
        console.log('💥 Layout Plugin détruit');
    }
}

// Export des classes pour usage externe si nécessaire
export { gridHandler, imageHandler, codeGenerator };

// Rendre les classes disponibles globalement pour compatibilité
if (typeof window !== 'undefined') {
    window.LayoutPluginClasses = {
        Layout,
        gridHandler,
        imageHandler,
        codeGenerator
    };
}