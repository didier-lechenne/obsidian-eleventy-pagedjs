import pageMove from './pageMove.js';
export default pageMove;

